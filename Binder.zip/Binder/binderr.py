import os
import keyboard
import subprocess
import pyfiglet
import json

def open_app(app_path):
    try:
        subprocess.Popen(app_path, shell=True)
        print(f"App opened: {app_path}")
        show_notification("Application opened successfully!")
    except FileNotFoundError:
        print(f"Invalid app path: {app_path}")

def set_password():
    password = input("Enter a password to secure this binding: ")
    confirm_password = input("Confirm password: ")
    if password == confirm_password:
        return password
    else:
        print("Passwords do not match.")
        return None

def open_app_with_password(app_path, password):
    while True:
        entered_password = input("Enter password: ")
        if entered_password == password:
            open_app(app_path)
            break
        else:
            print("Incorrect password. Please try again.")

def show_notification(message):
    print(message)

def print_big_text(text):
    ascii_art = pyfiglet.figlet_format(text, font="banner")
    print(ascii_art)

def save_settings(settings):
    with open("settings.json", 'w') as f:
        json.dump(settings, f)

def load_settings():
    try:
        with open("settings.json", 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def setup_hotkeys():
    hotkeys = {}
    
    while True:
        hotkey = input("Enter the hotkey combination (or type 'exit' to finish): ")
        if hotkey.lower() == 'exit':
            break
        
        app_path = input("Enter the path of the application: ")
        password = input("Enter a password (leave blank if none): ")

        hotkeys[hotkey] = (app_path, password)

    return hotkeys

def add_hotkeys():
    settings = load_settings()
    hotkeys = settings.get("hotkeys", {})
    
    new_hotkeys = setup_hotkeys()
    hotkeys.update(new_hotkeys)

    settings["hotkeys"] = hotkeys
    save_settings(settings)

def clean_settings():
    if input("Are you sure you want to clean all settings? This action cannot be undone. (yes/no): ").lower() == "yes":
        save_settings({})
        print("Settings cleaned successfully.")

def main():
    print_big_text("BINDER")
    print("Welcome to the Binder!")

    # Set a unique Command Prompt window title
    os.system("title Binder_Window")

    try:
        while True:
            print("\nOptions:")
            print("1. Open application")
            print("2. Add hotkeys")
            print("3. Clean settings")
            print("4. Exit")
            
            choice = input("Enter your choice: ")
            
            if choice == '1':
                settings = load_settings()
                hotkeys = settings.get("hotkeys", {})
                if not hotkeys:
                    print("No hotkeys found. Please add hotkeys first.")
                else:
                    for hotkey, (app_path, password) in hotkeys.items():
                        try:
                            if password:
                                keyboard.add_hotkey(hotkey, open_app_with_password, args=(app_path, password))
                            else:
                                keyboard.add_hotkey(hotkey, open_app, args=(app_path,))
                            print(f"Binding set: Hotkey - {hotkey}, App Path - {app_path}")
                        except Exception as e:
                            print(f"Error registering hotkey: {e}")

                print("Press esc to exit.")
                keyboard.wait("esc")
                break
            elif choice == '2':
                add_hotkeys()
            elif choice == '3':
                clean_settings()
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please try again.")
    finally:
        # Close the Command Prompt window
        os.system('taskkill /f /im cmd.exe')

if __name__ == "__main__":
    main()
